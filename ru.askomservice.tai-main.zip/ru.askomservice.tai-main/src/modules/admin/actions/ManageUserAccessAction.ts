import { ManageUserAccessDto } from "@/modules/admin/dto/ManageUserAccessDto";

/**
 * ManageUserAccessAction:
 * Действие для управления доступом к боту.
 * Реализует добавление, удаление и просмотр списка (whitelist) пользователей.
 */
export class ManageUserAccessAction {
  async execute(request: ManageUserAccessDto): Promise<void> {
    // Логика управления доступом к боту
  }
}
