/**
 * UploadCRMDataAction:
 * Обрабатывает загрузку файла-дампа (JSON) с данными из CRM.
 * Использует DTO UploadFileDto для проверки и передачи данных файла.
 */
import { UploadFileDto } from "../dto/UploadFileDto";

export class UploadCRMDataAction {
  async execute(file: UploadFileDto): Promise<void> {
    // Логика валидации и хранения файла в файловом хранилище
    console.log("Uploading CRM data file:", file.filename);
    // Реализуйте логику хранения файла здесь
  }
}
