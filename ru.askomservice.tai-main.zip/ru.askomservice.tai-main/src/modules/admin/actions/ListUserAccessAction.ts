import { UserAccess } from "@/modules/admin/dto/UserAccess";

/**
 * ListUserAccessAction:
 * Возвращает список всех пользователей и их прав доступа.
 */
export class ListUserAccessAction {
  async execute(): Promise<UserAccess[]> {
    // Возвращает массив объектов UserAccess

    return [];
  }
}
